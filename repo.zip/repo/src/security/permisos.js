// Autorización por rol (RBAC). ADMIN: todo. OPERADOR: leer y registrar, sin borrar ni importar. CONSULTA: solo lectura.
function permitido(rol, metodo, ruta) {
  switch (rol) {
    case "ADMIN": return true;
    case "OPERADOR": return metodo !== "DELETE" && !ruta.startsWith("/api/import/");
    case "CONSULTA": return metodo === "GET";
    default: return false;
  }
}
module.exports = { permitido };
