/** DTO de entrada: validan y normalizan los datos externos antes de llegar al negocio. */
package com.artesanialegado.dto;
